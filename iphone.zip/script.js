function toggleMenu() {
    document.getElementById('menu').classList.toggle('active');
}

document.getElementById('contactForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value;

    if (name.length < 3) {
        alert('اخطار ! اسم شما باید حداقل بیشتر از سه حرف داشته باشد.');
    } else {
        alert('با تشکر پیام شما دریافت شد');
    }
});
function toggleMoreInfo() {
    const infoDiv = document.getElementById('more-info');
    if (infoDiv.style.display === 'none') {
        infoDiv.style.display = 'block';
        // انیمیشن ساده با JS
        infoDiv.style.animation = 'fadeIn 0.5s ease';
    } else {
        infoDiv.style.display = 'none';
        // انتخاب المان‌ها (اسم‌ها رو با کلاس‌های توی HTML چک کن)
const hamburger = document.querySelector('.hamburger'); // کلاس دکمه منو
const navMenu = document.querySelector('.nav-menu');   // کلاس منوی کشویی

// اضافه کردن قابلیت کلیک برای باز و بسته شدن
hamburger.addEventListener('click', () => {
    navMenu.classList.toggle('active');
});

    }
}

