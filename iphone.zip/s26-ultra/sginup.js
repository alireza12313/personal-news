let signupForm = document.getElementById("signupForm");

let signupPassword = document.getElementById("signupPassword");
let repeatPassword = document.getElementById("repeatPassword");

let showSignupPass = document.getElementById("showSignupPass");
let showRepeatPass = document.getElementById("showRepeatPass");


showSignupPass.addEventListener("click", function(){

if(signupPassword.type === "password"){

signupPassword.type = "text";
showSignupPass.innerText = "مخفی";

}else{

signupPassword.type = "password";
showSignupPass.innerText = "نمایش";

}

});


showRepeatPass.addEventListener("click", function(){

if(repeatPassword.type === "password"){

repeatPassword.type = "text";
showRepeatPass.innerText = "مخفی";

}else{

repeatPassword.type = "password";
showRepeatPass.innerText = "نمایش";

}

});


signupForm.addEventListener("submit", function(e){

e.preventDefault();

let name = document.getElementById("name").value.trim();
let email = document.getElementById("signupEmail").value.trim();
let pass = signupPassword.value;
let repeat = repeatPassword.value;
let terms = document.getElementById("terms").checked;


if(name === "" || email === "" || pass === "" || repeat === ""){

alert("لطفاً همه قسمت‌ها را پر کنید.");
return;

}


if(pass.length < 6){

alert("رمز عبور باید حداقل ۶ کاراکتر باشد.");
return;

}


if(pass !== repeat){

alert("رمزهای عبور با هم یکسان نیستند.");
return;

}


if(!terms){

alert("لطفاً قوانین و شرایط سایت را بپذیرید.");
return;

}


let button = signupForm.querySelector(".login-btn");

button.innerText = "در حال ساخت حساب...";
button.disabled = true;


setTimeout(function(){

alert("حساب شما با موفقیت ساخته شد.");

window.location.href = "login.html";

},1200);

});