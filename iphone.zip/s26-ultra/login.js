let form = document.getElementById("loginForm");
let password = document.getElementById("password");
let showPass = document.getElementById("showPass");


showPass.addEventListener("click", function(){

if(password.type === "password"){

password.type = "text";
showPass.innerText = "مخفی";

}else{

password.type = "password";
showPass.innerText = "نمایش";

}

});


form.addEventListener("submit", function(e){

e.preventDefault();

let email = document.getElementById("email").value.trim();
let pass = password.value.trim();

if(email === "" || pass === ""){

alert("لطفاً همه قسمت‌ها را پر کنید.");
return;

}

if(pass.length < 6){

alert("رمز عبور باید حداقل ۶ کاراکتر باشد.");
return;

}

let button = form.querySelector(".login-btn");

button.innerText = "در حال ورود...";
button.disabled = true;

setTimeout(function(){

alert("ورود با موفقیت انجام شد.");

window.location.href = "index.html";

},1000);

});