let images = [
"images/s26-1.jpg",
"images/s26-2.jpg",
"images/s26-3.jpg",
"images/s26-4.jpg"
];

let current = 0;

let slideImg = document.getElementById("slideImg");


function showSlide(){
if(!slideImg) return;

slideImg.style.opacity = "0";

setTimeout(function(){

slideImg.src = images[current];

slideImg.style.opacity = "1";

},250);
}


function nextSlide(){

current++;

if(current >= images.length){
current = 0;
}

showSlide();
}


function prevSlide(){

current--;

if(current < 0){
current = images.length - 1;
}

showSlide();
}


// عوض شدن خودکار عکس ها
setInterval(function(){

nextSlide();

},5000);


// دکمه خرید
function buyPhone(){

let ok = confirm("می‌خواهید Galaxy S26 Ultra را انتخاب کنید؟");

if(ok){

alert("گوشی به سبد خرید اضافه شد.");

}

}


// فرم تماس
function sendMessage(event){

event.preventDefault();

let inputs = event.target.querySelectorAll("input");

let name = inputs[0].value;

if(name.trim() === ""){

alert("لطفاً نام خود را وارد کنید.");
return;

}

alert("پیام شما با موفقیت ارسال شد.");

event.target.reset();

}


// وقتی صفحه اسکرول میشه هدر یه کم تغییر کنه
window.addEventListener("scroll", function(){

let header = document.querySelector(".top");

if(window.scrollY > 80){

header.style.boxShadow = "0 5px 25px rgba(0,0,0,.25)";

}else{

header.style.boxShadow = "none";

}

});


// لینک های منو
let menuLinks = document.querySelectorAll("nav a");

menuLinks.forEach(function(link){

link.addEventListener("click", function(){

menuLinks.forEach(function(item){

item.style.color = "";

});

this.style.color = "#9296ff";

});

});


// وقتی عکس اصلی لود شد
if(slideImg){

slideImg.addEventListener("load", function(){

slideImg.style.opacity = "1";

});

}


// انتخاب رنگ گوشی
let phoneColors = document.querySelectorAll(".color-list span");

phoneColors.forEach(function(color){

color.addEventListener("click", function(){

phoneColors.forEach(function(c){

c.style.borderColor = "#30334c";

});

this.style.borderColor = "#fff";

});

});